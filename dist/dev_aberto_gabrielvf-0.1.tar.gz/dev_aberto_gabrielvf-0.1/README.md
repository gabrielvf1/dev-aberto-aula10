Pacote desenvolvido para teste e aprendizagem
Repositorio da Disciplina: https://github.com/Insper/dev-aberto
